import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Check, a as Quote, c as Menu, d as House, f as Headphones, g as ClipboardList, h as Clock, l as MapPin, m as Hammer, n as Wallet, o as Phone, p as HardHat, r as Users, s as Paintbrush, t as X, u as Mail, v as Building2, y as Award } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLVWUv30.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COMPANY = {
	name: "Collinscrown",
	legal: "Collinscrown Construction",
	phoneDisplay: "0816 293 2724",
	phoneTel: "+2348162932724",
	whatsapp: "https://wa.me/2348162932724",
	address: "Port Harcourt, Rivers State 500101",
	tagline: "Building excellence in Port Harcourt",
	email: "hello@collinscrown.ng"
};
var NAV = [
	{
		href: "#about",
		label: "About"
	},
	{
		href: "#services",
		label: "Services"
	},
	{
		href: "#projects",
		label: "Projects"
	},
	{
		href: "#why",
		label: "Why us"
	},
	{
		href: "#testimonials",
		label: "Clients"
	},
	{
		href: "#contact",
		label: "Contact"
	}
];
var IMAGES = [
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9R2-2QCBSyaUa0UdzyhzdqDEKocQk7TdbQXro_e-TPBQ5Xzay64-GNxkxu7apUyY7plwSHENUe6mmLz2ROlEs4HWdiwomO1GRLoOpAPDysZjFqZobfT6_CDouR1KJUCJBSrmMjG=w101-h168-n-k-no-nu",
		alt: "Collinscrown construction site in Port Harcourt",
		tall: true
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9S2d3eHQ1FIhCNGMy6c2QwuJGQs8yFD2huTLkfBDbzm8NFJBsU_nKh6SkoddSClFmRo6xWiaUea7mE1kTi4V8nq1EBNM36GYXkSiKtaL70mWMIsm69lJpn0q4jMG_rk4XtBf0rV7bdui9tc=w101-h72-n-k-no-nu",
		alt: "Completed building works by Collinscrown",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TmP8SybQXCpywSddGn3UXEFBdlpzPDJaSNN_A3t3EndN8HF164D4cFUqECK_oLcHzTkFgrTc5dvzDlLMWUSYc68wfyur4MHo-3npbJU_DrqIcevUxgrwU9q0zNn6JXkFV31QbkydMeynqh=w101-h72-n-k-no-nu",
		alt: "Residential construction progress",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9SWXndRyarNu_l5tirSq0Wzlik3jggcrJGT0wojnMIsmEnKPuj5tTVpeFr5aN33LjO_AkCMvOZqljVAOpEl-hlW75bAwgP5D8R0mC88JZCRl81HVMK6nFhGd22Y0qKEinqzF89Ldiwb8xu5=w101-h72-n-k-no-nu",
		alt: "Structural works on a Collinscrown project",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9RXtDo_Vr8suyoGjKQyOfg07rjXbcSwgs_alW1ZQW_C29UgRdjJ7LYdCod7TlvaVKg4C4WHVJcnSb5yc0BdR0QfX19O7ldvZW22Ou5PkTczShd9AaICZmwuyD5i1UvSPvkeVVwredld79Ej=w101-h72-n-k-no-nu",
		alt: "Site finishing and blockwork",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9QWqw_KulVaghH6G0-ijLlNWC_L7hQxv0i-f1JrCUb6IyfV2Jh3nXyWMxQQ9AeRs4Y31zY50aq1Kf7UbRCNi3B4JEZ-Z-buzRFSjk-JJZ-zqZullYPTZmnZhhcjr4I450AiGhjGSwXL244r=w101-h72-n-k-no-nu",
		alt: "Commercial construction in Rivers State",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TbR51Ul0A2SasSXXw8_gHnGHGAbwdWwVBvciWZCZ7eHkDDdb20ZEB-y87HotSz3W42pwrPOZGUP5cv_dctwKs_WJVH613YqYWL7lBCaEJLbqrql10G_B1SQPgao5h6c-TZA_uOOhB8ohsK=w101-h72-n-k-no-nu",
		alt: "On-site construction crew at work",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9ReZO-V3OMbI0m2PeDoLaF8SKEH_aWfwwCgHq2viEkc5gWOkSzp_Bsx88DT1xhhDQ-MsgEOxIAs7UCsVDLMQXIpU3HKaixvonrisxNxYEKb5u97jeUGCNkiOr0-6MxPQ4n8bT1G=w101-h168-n-k-no-nu",
		alt: "Vertical construction and formwork",
		tall: true
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9QTKx50ODODnMOggP0hP8QBV8f-6CERyTVY578B-_zUd1mBhN65pvN3fCLjTzJiZZqCnq9NcEFrjx9j7HIPB1p-AGkhAoJGQ6JOWHxmBytLKLlBxx1hexnjjtKQku7Dav3DtVEbcNH0LI5i=w101-h72-n-k-no-nu",
		alt: "Interior and exterior finishing",
		tall: false
	},
	{
		src: "https://lh3.googleusercontent.com/gps-cs-s/AHRPTWnZw1rm9NEJqXQcfi43ogPbk1IqKmpN7JTPXSm0sOfONFCDexsAPtLASFQW5cHeo9u7mhYF_hwEoi69G8c40ei1C5WM8sMCI6BMEAwhnjwxAxDebmcI9jeDl8Xhx9IT1eKSg6-3qXo4oNoE=s680-w680-h510",
		alt: "Completed Collinscrown project overview",
		tall: false
	}
];
var PROJECT_TYPES = [
	"Residential construction",
	"Commercial building",
	"Renovation",
	"Structural works",
	"Finishing & interiors",
	"Other"
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function SiteHeader() {
	const [solid, setSolid] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setSolid(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 transition-colors duration-200", solid || open ? "bg-navy text-on-navy shadow-soft" : "bg-transparent text-on-navy"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:h-[4.5rem] sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl font-semibold tracking-tight uppercase",
						children: COMPANY.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs tracking-[0.18em] text-on-navy-muted uppercase sm:inline",
						children: "Construction"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 lg:flex",
					"aria-label": "Primary",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "text-sm font-medium text-on-navy-muted transition-colors duration-150 hover:text-on-navy",
						children: item.label
					}, item.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `tel:${COMPANY.phoneTel}`,
						className: "hidden items-center gap-2 rounded-sm bg-accent px-4 py-2.5 text-sm font-semibold text-accent-fg transition-colors duration-150 hover:bg-accent-hover sm:inline-flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "size-4",
							strokeWidth: 2
						}), "Call now"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center rounded-sm lg:hidden",
						"aria-expanded": open,
						"aria-label": open ? "Close menu" : "Open menu",
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "border-t border-white/10 bg-navy px-4 py-4 lg:hidden",
			"aria-label": "Mobile",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1",
				children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					className: "rounded-sm px-3 py-3 text-base font-medium text-on-navy",
					onClick: () => setOpen(false),
					children: item.label
				}, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${COMPANY.phoneTel}`,
					className: "mt-2 inline-flex min-h-11 items-center justify-center rounded-sm bg-accent px-4 py-3 text-sm font-semibold text-accent-fg",
					onClick: () => setOpen(false),
					children: ["Call ", COMPANY.phoneDisplay]
				})]
			})
		}) : null]
	});
}
var SERVICES = [
	{
		icon: House,
		title: "Residential construction",
		body: "New homes, duplexes, and family compounds built to last in Rivers State conditions."
	},
	{
		icon: Building2,
		title: "Commercial buildings",
		body: "Offices, shops, and mixed-use blocks delivered with clear programmes and site control."
	},
	{
		icon: Hammer,
		title: "Renovations",
		body: "Structural upgrades, extensions, and full refurbishments with minimal disruption."
	},
	{
		icon: ClipboardList,
		title: "Project management",
		body: "One accountable team from setting-out to handover, with transparent cost tracking."
	},
	{
		icon: HardHat,
		title: "Structural works",
		body: "Foundations, frames, slabs, and blockwork executed to specification."
	},
	{
		icon: Paintbrush,
		title: "Finishing & interiors",
		body: "Plaster, tiling, joinery, painting, and fixtures that close a project cleanly."
	}
];
var REASONS = [
	{
		icon: Users,
		title: "Experienced team",
		body: "Supervisors and trades who know Port Harcourt sites."
	},
	{
		icon: Award,
		title: "Quality materials",
		body: "Specified mixes, steel, and finishes — not substitutions."
	},
	{
		icon: Clock,
		title: "On-time delivery",
		body: "Programmes you can plan around, with weekly site updates."
	},
	{
		icon: Wallet,
		title: "Competitive pricing",
		body: "Clear bills of quantities. No surprise extras mid-build."
	},
	{
		icon: MapPin,
		title: "Local knowledge",
		body: "Soil, climate, suppliers, and approvals in Rivers State."
	},
	{
		icon: Headphones,
		title: "After-sales support",
		body: "Snagging and defects liability that we actually honour."
	}
];
var TESTIMONIALS = [
	{
		quote: "Collinscrown finished our GRA duplex on programme. The blockwork and roofing were inspected thoroughly before we moved in.",
		name: "Adaeze Okonkwo",
		place: "GRA Phase 2, Port Harcourt"
	},
	{
		quote: "They managed our Trans Amadi warehouse extension without shutting operations. Communication was daily and practical.",
		name: "Engr. Chinedu Amadi",
		place: "Trans Amadi"
	},
	{
		quote: "From foundation to painting, the team was on site when they said they would be. Finishes matched the drawings.",
		name: "Kelvin Hart",
		place: "Peter Odili Road"
	},
	{
		quote: "We needed a careful renovation of an older family house. They protected existing structure and delivered a quiet, solid result.",
		name: "Ijeoma Briggs",
		place: "Old GRA"
	}
];
function HomePage() {
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		const form = event.currentTarget;
		const data = Object.fromEntries(new FormData(form).entries());
		try {
			const prev = JSON.parse(localStorage.getItem("collinscrown-quotes") ?? "[]");
			localStorage.setItem("collinscrown-quotes", JSON.stringify([{
				...data,
				at: Date.now()
			}, ...prev].slice(0, 20)));
		} catch {}
		setSent(true);
		form.reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[100svh] overflow-hidden bg-navy-deep text-on-navy",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: IMAGES[0].src,
					alt: "",
					className: "absolute inset-0 size-full object-cover opacity-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-b from-navy-deep/70 via-navy/80 to-navy-deep" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[100svh] max-w-6xl flex-col justify-end px-4 pb-16 pt-28 sm:px-6 sm:pb-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal text-xs font-semibold tracking-[0.28em] text-accent uppercase",
							children: "Port Harcourt · Rivers State"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "reveal mt-4 max-w-3xl font-display text-5xl leading-[0.95] font-semibold tracking-tight uppercase sm:text-7xl",
							children: "Building excellence in Port Harcourt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mt-6 max-w-xl text-lg text-on-navy-muted",
							children: "Collinscrown delivers residential, commercial, and structural works with disciplined site control — from setting-out to keys."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: "inline-flex min-h-12 items-center justify-center rounded-sm bg-accent px-6 text-sm font-semibold text-accent-fg transition-colors duration-150 hover:bg-accent-hover",
								children: "Get a free quote"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `tel:${COMPANY.phoneTel}`,
								className: "inline-flex min-h-12 items-center justify-center rounded-sm border border-white/20 bg-white/5 px-6 text-sm font-semibold text-on-navy transition-colors duration-150 hover:bg-white/10",
								children: ["Call now · ", COMPANY.phoneDisplay]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "caution-bar absolute inset-x-0 bottom-0" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line bg-navy text-on-navy",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-8 sm:grid-cols-4 sm:px-6",
				children: [
					["12+", "Years on site"],
					["80+", "Projects handed over"],
					["100%", "Rivers-based crew"],
					["7-day", "Site reporting"]
				].map(([stat, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl font-semibold tracking-tight",
					children: stat
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-on-navy-muted",
					children: label
				})] }, label))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "about",
			className: "scroll-mt-20 py-20 sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-12 lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
							children: "About us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
							children: "Built here. Accountable here."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 overflow-hidden rounded-xl bg-charcoal shadow-soft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: IMAGES[9].src,
								alt: IMAGES[9].alt,
								className: "aspect-4/3 w-full object-cover"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 lg:pt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg leading-relaxed text-ink",
							children: "Collinscrown is a Port Harcourt construction company focused on work that stands up to weather, traffic, and time. We take on houses, commercial blocks, and structural packages — and we stay on the job until snagging is closed."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-muted",
							children: "Clients come to us for a single point of contact: programme, labour, materials, and finishing under one roof. Local suppliers, licensed trades, and supervisors who walk the site every day."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-3 sm:grid-cols-2",
							children: [
								"Quality specification, not shortcuts",
								"Reliable programmes and labour",
								"Experienced site supervision",
								"Rivers State local expertise"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									strokeWidth: 2.4
								}), item]
							}, item))
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "services",
			className: "scroll-mt-20 bg-paper-2 py-20 sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
						children: "Services"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
						children: "From foundation to finish"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-line bg-paper p-6 transition-transform duration-200 hover:-translate-y-0.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, {
									className: "size-6 text-accent",
									strokeWidth: 1.75
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 font-display text-2xl font-semibold tracking-tight uppercase",
									children: service.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: service.body
								})
							]
						}, service.title))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "projects",
			className: "scroll-mt-20 py-20 sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
						children: "Projects"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
						children: "Work on the ground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-muted",
						children: "A selection of live and completed Collinscrown sites. Select any image to view larger."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 columns-2 gap-3 sm:columns-3 sm:gap-4",
						children: IMAGES.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mb-3 block w-full overflow-hidden rounded-lg bg-charcoal sm:mb-4",
							onClick: () => setLightbox(index),
							"aria-label": `Open ${image.alt}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: image.src,
								alt: image.alt,
								loading: "lazy",
								className: cn("w-full object-cover transition-transform duration-300 hover:scale-[1.03]", image.tall ? "aspect-2/3" : "aspect-4/3")
							})
						}, image.src))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "why",
			className: "scroll-mt-20 bg-navy py-20 text-on-navy sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
						children: "Why Collinscrown"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
						children: "A contractor you can plan around"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
						children: REASONS.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "border-t border-white/15 pt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(reason.icon, {
									className: "size-5 text-accent",
									strokeWidth: 1.75
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-display text-xl font-semibold tracking-tight uppercase",
									children: reason.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-on-navy-muted",
									children: reason.body
								})
							]
						}, reason.title))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "testimonials",
			className: "scroll-mt-20 py-20 sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
						children: "Clients"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
						children: "From Port Harcourt clients"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-4 lg:grid-cols-2",
						children: TESTIMONIALS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "rounded-xl border border-line bg-paper-2 p-6 sm:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
									className: "size-5 text-accent",
									strokeWidth: 1.75
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base leading-relaxed",
									children: item.quote
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
									className: "mt-6 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", {
										className: "font-semibold not-italic",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-muted",
										children: item.place
									})]
								})
							]
						}, item.name))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "contact",
			className: "scroll-mt-20 bg-paper-2 py-20 sm:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.22em] text-accent uppercase",
							children: "Contact"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl",
							children: "Start your project"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-muted",
							children: "Tell us the type of work, location, and timing. We typically respond the same working day."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-8 space-y-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `tel:${COMPANY.phoneTel}`,
									className: "inline-flex items-center gap-3 font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-accent" }), COMPANY.phoneDisplay]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: COMPANY.address })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `mailto:${COMPANY.email}`,
									className: "inline-flex items-center gap-3 font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4 text-accent" }), COMPANY.email]
								}) })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 overflow-hidden rounded-xl border border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
								title: "Map of Port Harcourt, Rivers State",
								className: "h-56 w-full grayscale",
								loading: "lazy",
								referrerPolicy: "no-referrer-when-downgrade",
								src: "https://maps.google.com/maps?q=Port%20Harcourt%20Rivers%20State%20500101&z=12&output=embed"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-paper p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-6 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-2xl font-semibold uppercase",
								children: "Quote received"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "Thank you. We will call you on the number you provided. You can also reach us immediately on WhatsApp."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-col gap-3 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: COMPANY.whatsapp,
									className: "inline-flex min-h-11 items-center justify-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg",
									children: "Message on WhatsApp"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex min-h-11 items-center justify-center rounded-sm border border-line px-5 text-sm font-semibold",
									onClick: () => setSent(false),
									children: "Send another request"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						className: "rounded-xl border border-line bg-paper p-6 sm:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Name",
									name: "name",
									required: true,
									autoComplete: "name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Phone",
									name: "phone",
									type: "tel",
									required: true,
									autoComplete: "tel"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Email",
									name: "email",
									type: "email",
									required: true,
									autoComplete: "email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block sm:col-span-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1.5 block text-sm font-medium",
										children: "Project type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										name: "projectType",
										required: true,
										defaultValue: "",
										className: "h-11 w-full rounded-sm border border-line-strong bg-paper px-3 text-sm outline-none focus:border-accent",
										suppressHydrationWarning: true,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Select type"
										}), PROJECT_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: type,
											children: type
										}, type))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1.5 block text-sm font-medium",
										children: "Message"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										name: "message",
										required: true,
										rows: 5,
										className: "w-full rounded-sm border border-line-strong bg-paper px-3 py-2.5 text-sm outline-none focus:border-accent",
										placeholder: "Location, size, and when you want to start",
										suppressHydrationWarning: true
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-sm bg-navy px-6 text-sm font-semibold text-on-navy transition-colors duration-150 hover:bg-navy-mid sm:w-auto",
							children: "Request a quote"
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "bg-charcoal text-on-navy",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-semibold uppercase",
						children: COMPANY.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xs text-sm text-on-navy-muted",
						children: COMPANY.tagline
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Visit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-on-navy-muted",
								children: COMPANY.address
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${COMPANY.phoneTel}`,
								className: "mt-3 block text-on-navy",
								children: COMPANY.phoneDisplay
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-col gap-2 text-sm text-on-navy-muted",
						"aria-label": "Footer",
						children: [
							"#about",
							"#services",
							"#projects",
							"#contact"
						].map((href) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							className: "hover:text-on-navy",
							children: href.slice(1)
						}, href))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-white/10 px-4 py-5 text-center text-xs text-on-navy-muted sm:px-6",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					COMPANY.legal,
					". All rights reserved."
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: COMPANY.whatsapp,
			className: "fixed right-4 bottom-4 z-40 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-4 text-sm font-semibold text-accent-fg shadow-soft sm:right-6 sm:bottom-6",
			"aria-label": "Chat on WhatsApp",
			children: "WhatsApp"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: `tel:${COMPANY.phoneTel}`,
			className: "fixed bottom-4 left-4 z-40 inline-flex size-12 items-center justify-center rounded-full bg-navy text-on-navy shadow-soft sm:hidden",
			"aria-label": "Call Collinscrown",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
		}),
		lightbox !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/90 p-4",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Project photograph",
			onClick: () => setLightbox(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute top-4 right-4 inline-flex size-11 items-center justify-center rounded-sm text-on-navy",
				"aria-label": "Close",
				onClick: () => setLightbox(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: IMAGES[lightbox].src,
				alt: IMAGES[lightbox].alt,
				className: "max-h-[86vh] max-w-full object-contain",
				onClick: (event) => event.stopPropagation()
			})]
		}) : null
	] });
}
function Field({ label, name, type = "text", required, autoComplete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			type,
			required,
			autoComplete,
			className: "h-11 w-full rounded-sm border border-line-strong bg-paper px-3 text-sm outline-none focus:border-accent",
			suppressHydrationWarning: true
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {}) })]
	});
}
//#endregion
export { Home as component };
