//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DrWTYCaz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CAMKSyAl.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CAMKSyAl.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DzRNmZwP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
