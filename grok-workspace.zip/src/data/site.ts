export const COMPANY = {
  name: "Collinscrown",
  legal: "Collinscrown Construction",
  phoneDisplay: "0816 293 2724",
  phoneTel: "+2348162932724",
  whatsapp: "https://wa.me/2348162932724",
  address: "Port Harcourt, Rivers State 500101",
  tagline: "Building excellence in Port Harcourt",
  email: "hello@collinscrown.ng",
} as const;

export const NAV = [
  { href: "#about", label: "About" },
  { href: "#services", label: "Services" },
  { href: "#projects", label: "Projects" },
  { href: "#why", label: "Why us" },
  { href: "#testimonials", label: "Clients" },
  { href: "#contact", label: "Contact" },
] as const;

export const IMAGES = [
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9R2-2QCBSyaUa0UdzyhzdqDEKocQk7TdbQXro_e-TPBQ5Xzay64-GNxkxu7apUyY7plwSHENUe6mmLz2ROlEs4HWdiwomO1GRLoOpAPDysZjFqZobfT6_CDouR1KJUCJBSrmMjG=w101-h168-n-k-no-nu",
    alt: "Collinscrown construction site in Port Harcourt",
    tall: true,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9S2d3eHQ1FIhCNGMy6c2QwuJGQs8yFD2huTLkfBDbzm8NFJBsU_nKh6SkoddSClFmRo6xWiaUea7mE1kTi4V8nq1EBNM36GYXkSiKtaL70mWMIsm69lJpn0q4jMG_rk4XtBf0rV7bdui9tc=w101-h72-n-k-no-nu",
    alt: "Completed building works by Collinscrown",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TmP8SybQXCpywSddGn3UXEFBdlpzPDJaSNN_A3t3EndN8HF164D4cFUqECK_oLcHzTkFgrTc5dvzDlLMWUSYc68wfyur4MHo-3npbJU_DrqIcevUxgrwU9q0zNn6JXkFV31QbkydMeynqh=w101-h72-n-k-no-nu",
    alt: "Residential construction progress",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9SWXndRyarNu_l5tirSq0Wzlik3jggcrJGT0wojnMIsmEnKPuj5tTVpeFr5aN33LjO_AkCMvOZqljVAOpEl-hlW75bAwgP5D8R0mC88JZCRl81HVMK6nFhGd22Y0qKEinqzF89Ldiwb8xu5=w101-h72-n-k-no-nu",
    alt: "Structural works on a Collinscrown project",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9RXtDo_Vr8suyoGjKQyOfg07rjXbcSwgs_alW1ZQW_C29UgRdjJ7LYdCod7TlvaVKg4C4WHVJcnSb5yc0BdR0QfX19O7ldvZW22Ou5PkTczShd9AaICZmwuyD5i1UvSPvkeVVwredld79Ej=w101-h72-n-k-no-nu",
    alt: "Site finishing and blockwork",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9QWqw_KulVaghH6G0-ijLlNWC_L7hQxv0i-f1JrCUb6IyfV2Jh3nXyWMxQQ9AeRs4Y31zY50aq1Kf7UbRCNi3B4JEZ-Z-buzRFSjk-JJZ-zqZullYPTZmnZhhcjr4I450AiGhjGSwXL244r=w101-h72-n-k-no-nu",
    alt: "Commercial construction in Rivers State",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TbR51Ul0A2SasSXXw8_gHnGHGAbwdWwVBvciWZCZ7eHkDDdb20ZEB-y87HotSz3W42pwrPOZGUP5cv_dctwKs_WJVH613YqYWL7lBCaEJLbqrql10G_B1SQPgao5h6c-TZA_uOOhB8ohsK=w101-h72-n-k-no-nu",
    alt: "On-site construction crew at work",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9ReZO-V3OMbI0m2PeDoLaF8SKEH_aWfwwCgHq2viEkc5gWOkSzp_Bsx88DT1xhhDQ-MsgEOxIAs7UCsVDLMQXIpU3HKaixvonrisxNxYEKb5u97jeUGCNkiOr0-6MxPQ4n8bT1G=w101-h168-n-k-no-nu",
    alt: "Vertical construction and formwork",
    tall: true,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9QTKx50ODODnMOggP0hP8QBV8f-6CERyTVY578B-_zUd1mBhN65pvN3fCLjTzJiZZqCnq9NcEFrjx9j7HIPB1p-AGkhAoJGQ6JOWHxmBytLKLlBxx1hexnjjtKQku7Dav3DtVEbcNH0LI5i=w101-h72-n-k-no-nu",
    alt: "Interior and exterior finishing",
    tall: false,
  },
  {
    src: "https://lh3.googleusercontent.com/gps-cs-s/AHRPTWnZw1rm9NEJqXQcfi43ogPbk1IqKmpN7JTPXSm0sOfONFCDexsAPtLASFQW5cHeo9u7mhYF_hwEoi69G8c40ei1C5WM8sMCI6BMEAwhnjwxAxDebmcI9jeDl8Xhx9IT1eKSg6-3qXo4oNoE=s680-w680-h510",
    alt: "Completed Collinscrown project overview",
    tall: false,
  },
] as const;

export const PROJECT_TYPES = [
  "Residential construction",
  "Commercial building",
  "Renovation",
  "Structural works",
  "Finishing & interiors",
  "Other",
] as const;
