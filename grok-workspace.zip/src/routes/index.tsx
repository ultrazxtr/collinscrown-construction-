import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/header";
import { HomePage } from "@/components/site/home-page";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div id="top">
      <SiteHeader />
      <main>
        <HomePage />
      </main>
    </div>
  );
}
