import { useEffect, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { COMPANY, NAV } from "@/data/site";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-200",
        solid || open ? "bg-navy text-on-navy shadow-soft" : "bg-transparent text-on-navy",
      )}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:h-[4.5rem] sm:px-6">
        <a href="#top" className="flex items-baseline gap-2">
          <span className="font-display text-2xl font-semibold tracking-tight uppercase">
            {COMPANY.name}
          </span>
          <span className="hidden text-xs tracking-[0.18em] text-on-navy-muted uppercase sm:inline">
            Construction
          </span>
        </a>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-on-navy-muted transition-colors duration-150 hover:text-on-navy"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${COMPANY.phoneTel}`}
            className="hidden items-center gap-2 rounded-sm bg-accent px-4 py-2.5 text-sm font-semibold text-accent-fg transition-colors duration-150 hover:bg-accent-hover sm:inline-flex"
          >
            <Phone className="size-4" strokeWidth={2} />
            Call now
          </a>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-sm lg:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>

      {open ? (
        <nav
          className="border-t border-white/10 bg-navy px-4 py-4 lg:hidden"
          aria-label="Mobile"
        >
          <div className="flex flex-col gap-1">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="rounded-sm px-3 py-3 text-base font-medium text-on-navy"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a
              href={`tel:${COMPANY.phoneTel}`}
              className="mt-2 inline-flex min-h-11 items-center justify-center rounded-sm bg-accent px-4 py-3 text-sm font-semibold text-accent-fg"
              onClick={() => setOpen(false)}
            >
              Call {COMPANY.phoneDisplay}
            </a>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
