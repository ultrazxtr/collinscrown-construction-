import { useState, type FormEvent } from "react";
import {
  Award,
  Building2,
  Check,
  ClipboardList,
  Clock,
  Hammer,
  HardHat,
  Headphones,
  Home,
  Mail,
  MapPin,
  Paintbrush,
  Phone,
  Quote,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { COMPANY, IMAGES, PROJECT_TYPES } from "@/data/site";
import { cn } from "@/lib/utils";

const SERVICES = [
  {
    icon: Home,
    title: "Residential construction",
    body: "New homes, duplexes, and family compounds built to last in Rivers State conditions.",
  },
  {
    icon: Building2,
    title: "Commercial buildings",
    body: "Offices, shops, and mixed-use blocks delivered with clear programmes and site control.",
  },
  {
    icon: Hammer,
    title: "Renovations",
    body: "Structural upgrades, extensions, and full refurbishments with minimal disruption.",
  },
  {
    icon: ClipboardList,
    title: "Project management",
    body: "One accountable team from setting-out to handover, with transparent cost tracking.",
  },
  {
    icon: HardHat,
    title: "Structural works",
    body: "Foundations, frames, slabs, and blockwork executed to specification.",
  },
  {
    icon: Paintbrush,
    title: "Finishing & interiors",
    body: "Plaster, tiling, joinery, painting, and fixtures that close a project cleanly.",
  },
];

const REASONS = [
  { icon: Users, title: "Experienced team", body: "Supervisors and trades who know Port Harcourt sites." },
  { icon: Award, title: "Quality materials", body: "Specified mixes, steel, and finishes — not substitutions." },
  { icon: Clock, title: "On-time delivery", body: "Programmes you can plan around, with weekly site updates." },
  { icon: Wallet, title: "Competitive pricing", body: "Clear bills of quantities. No surprise extras mid-build." },
  { icon: MapPin, title: "Local knowledge", body: "Soil, climate, suppliers, and approvals in Rivers State." },
  { icon: Headphones, title: "After-sales support", body: "Snagging and defects liability that we actually honour." },
];

const TESTIMONIALS = [
  {
    quote:
      "Collinscrown finished our GRA duplex on programme. The blockwork and roofing were inspected thoroughly before we moved in.",
    name: "Adaeze Okonkwo",
    place: "GRA Phase 2, Port Harcourt",
  },
  {
    quote:
      "They managed our Trans Amadi warehouse extension without shutting operations. Communication was daily and practical.",
    name: "Engr. Chinedu Amadi",
    place: "Trans Amadi",
  },
  {
    quote:
      "From foundation to painting, the team was on site when they said they would be. Finishes matched the drawings.",
    name: "Kelvin Hart",
    place: "Peter Odili Road",
  },
  {
    quote:
      "We needed a careful renovation of an older family house. They protected existing structure and delivered a quiet, solid result.",
    name: "Ijeoma Briggs",
    place: "Old GRA",
  },
];

export function HomePage() {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [sent, setSent] = useState(false);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const prev = JSON.parse(localStorage.getItem("collinscrown-quotes") ?? "[]") as unknown[];
      localStorage.setItem("collinscrown-quotes", JSON.stringify([{ ...data, at: Date.now() }, ...prev].slice(0, 20)));
    } catch {
      /* ignore quota */
    }
    setSent(true);
    form.reset();
  }

  return (
    <>
      <section className="relative min-h-[100svh] overflow-hidden bg-navy-deep text-on-navy">
        <img
          src={IMAGES[0].src}
          alt=""
          className="absolute inset-0 size-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-linear-to-b from-navy-deep/70 via-navy/80 to-navy-deep" />
        <div className="relative mx-auto flex min-h-[100svh] max-w-6xl flex-col justify-end px-4 pb-16 pt-28 sm:px-6 sm:pb-20">
          <p className="reveal text-xs font-semibold tracking-[0.28em] text-accent uppercase">
            Port Harcourt · Rivers State
          </p>
          <h1 className="reveal mt-4 max-w-3xl font-display text-5xl leading-[0.95] font-semibold tracking-tight uppercase sm:text-7xl">
            Building excellence in Port Harcourt
          </h1>
          <p className="reveal mt-6 max-w-xl text-lg text-on-navy-muted">
            Collinscrown delivers residential, commercial, and structural works with disciplined
            site control — from setting-out to keys.
          </p>
          <div className="reveal mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href="#contact"
              className="inline-flex min-h-12 items-center justify-center rounded-sm bg-accent px-6 text-sm font-semibold text-accent-fg transition-colors duration-150 hover:bg-accent-hover"
            >
              Get a free quote
            </a>
            <a
              href={`tel:${COMPANY.phoneTel}`}
              className="inline-flex min-h-12 items-center justify-center rounded-sm border border-white/20 bg-white/5 px-6 text-sm font-semibold text-on-navy transition-colors duration-150 hover:bg-white/10"
            >
              Call now · {COMPANY.phoneDisplay}
            </a>
          </div>
        </div>
        <div className="caution-bar absolute inset-x-0 bottom-0" />
      </section>

      <section className="border-b border-line bg-navy text-on-navy">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-8 sm:grid-cols-4 sm:px-6">
          {[
            ["12+", "Years on site"],
            ["80+", "Projects handed over"],
            ["100%", "Rivers-based crew"],
            ["7-day", "Site reporting"],
          ].map(([stat, label]) => (
            <div key={label}>
              <p className="font-display text-4xl font-semibold tracking-tight">{stat}</p>
              <p className="mt-1 text-sm text-on-navy-muted">{label}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="about" className="scroll-mt-20 py-20 sm:py-28">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">About us</p>
            <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
              Built here. Accountable here.
            </h2>
            <div className="mt-8 overflow-hidden rounded-xl bg-charcoal shadow-soft">
              <img src={IMAGES[9].src} alt={IMAGES[9].alt} className="aspect-4/3 w-full object-cover" />
            </div>
          </div>
          <div className="lg:col-span-7 lg:pt-10">
            <p className="text-lg leading-relaxed text-ink">
              Collinscrown is a Port Harcourt construction company focused on work that stands up to
              weather, traffic, and time. We take on houses, commercial blocks, and structural
              packages — and we stay on the job until snagging is closed.
            </p>
            <p className="mt-4 leading-relaxed text-muted">
              Clients come to us for a single point of contact: programme, labour, materials, and
              finishing under one roof. Local suppliers, licensed trades, and supervisors who walk
              the site every day.
            </p>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {[
                "Quality specification, not shortcuts",
                "Reliable programmes and labour",
                "Experienced site supervision",
                "Rivers State local expertise",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm font-medium">
                  <Check className="mt-0.5 size-4 shrink-0 text-accent" strokeWidth={2.4} />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section id="services" className="scroll-mt-20 bg-paper-2 py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">Services</p>
          <h2 className="mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
            From foundation to finish
          </h2>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((service) => (
              <article
                key={service.title}
                className="rounded-xl border border-line bg-paper p-6 transition-transform duration-200 hover:-translate-y-0.5"
              >
                <service.icon className="size-6 text-accent" strokeWidth={1.75} />
                <h3 className="mt-5 font-display text-2xl font-semibold tracking-tight uppercase">
                  {service.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{service.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="projects" className="scroll-mt-20 py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">Projects</p>
          <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
            Work on the ground
          </h2>
          <p className="mt-4 max-w-xl text-muted">
            A selection of live and completed Collinscrown sites. Select any image to view larger.
          </p>
          <div className="mt-10 columns-2 gap-3 sm:columns-3 sm:gap-4">
            {IMAGES.map((image, index) => (
              <button
                key={image.src}
                type="button"
                className="mb-3 block w-full overflow-hidden rounded-lg bg-charcoal sm:mb-4"
                onClick={() => setLightbox(index)}
                aria-label={`Open ${image.alt}`}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  loading="lazy"
                  className={cn(
                    "w-full object-cover transition-transform duration-300 hover:scale-[1.03]",
                    image.tall ? "aspect-2/3" : "aspect-4/3",
                  )}
                />
              </button>
            ))}
          </div>
        </div>
      </section>

      <section id="why" className="scroll-mt-20 bg-navy py-20 text-on-navy sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">Why Collinscrown</p>
          <h2 className="mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
            A contractor you can plan around
          </h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {REASONS.map((reason) => (
              <article key={reason.title} className="border-t border-white/15 pt-6">
                <reason.icon className="size-5 text-accent" strokeWidth={1.75} />
                <h3 className="mt-4 font-display text-xl font-semibold tracking-tight uppercase">
                  {reason.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-on-navy-muted">{reason.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="testimonials" className="scroll-mt-20 py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">Clients</p>
          <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
            From Port Harcourt clients
          </h2>
          <div className="mt-12 grid gap-4 lg:grid-cols-2">
            {TESTIMONIALS.map((item) => (
              <blockquote
                key={item.name}
                className="rounded-xl border border-line bg-paper-2 p-6 sm:p-8"
              >
                <Quote className="size-5 text-accent" strokeWidth={1.75} />
                <p className="mt-4 text-base leading-relaxed">{item.quote}</p>
                <footer className="mt-6 text-sm">
                  <cite className="font-semibold not-italic">{item.name}</cite>
                  <span className="mt-0.5 block text-muted">{item.place}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="scroll-mt-20 bg-paper-2 py-20 sm:py-28">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold tracking-[0.22em] text-accent uppercase">Contact</p>
            <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight uppercase sm:text-5xl">
              Start your project
            </h2>
            <p className="mt-4 leading-relaxed text-muted">
              Tell us the type of work, location, and timing. We typically respond the same working
              day.
            </p>
            <ul className="mt-8 space-y-4 text-sm">
              <li>
                <a href={`tel:${COMPANY.phoneTel}`} className="inline-flex items-center gap-3 font-medium">
                  <Phone className="size-4 text-accent" />
                  {COMPANY.phoneDisplay}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 size-4 text-accent" />
                <span>{COMPANY.address}</span>
              </li>
              <li>
                <a href={`mailto:${COMPANY.email}`} className="inline-flex items-center gap-3 font-medium">
                  <Mail className="size-4 text-accent" />
                  {COMPANY.email}
                </a>
              </li>
            </ul>
            <div className="mt-8 overflow-hidden rounded-xl border border-line">
              <iframe
                title="Map of Port Harcourt, Rivers State"
                className="h-56 w-full grayscale"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src="https://maps.google.com/maps?q=Port%20Harcourt%20Rivers%20State%20500101&z=12&output=embed"
              />
            </div>
          </div>

          <div className="lg:col-span-7">
            {sent ? (
              <div className="rounded-xl border border-line bg-paper p-8">
                <Check className="size-6 text-accent" />
                <h3 className="mt-4 font-display text-2xl font-semibold uppercase">Quote received</h3>
                <p className="mt-2 text-muted">
                  Thank you. We will call you on the number you provided. You can also reach us
                  immediately on WhatsApp.
                </p>
                <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                  <a
                    href={COMPANY.whatsapp}
                    className="inline-flex min-h-11 items-center justify-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg"
                  >
                    Message on WhatsApp
                  </a>
                  <button
                    type="button"
                    className="inline-flex min-h-11 items-center justify-center rounded-sm border border-line px-5 text-sm font-semibold"
                    onClick={() => setSent(false)}
                  >
                    Send another request
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={onSubmit}
                className="rounded-xl border border-line bg-paper p-6 sm:p-8"
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Name" name="name" required autoComplete="name" />
                  <Field label="Phone" name="phone" type="tel" required autoComplete="tel" />
                  <Field label="Email" name="email" type="email" required autoComplete="email" />
                  <label className="block sm:col-span-1">
                    <span className="mb-1.5 block text-sm font-medium">Project type</span>
                    <select
                      name="projectType"
                      required
                      defaultValue=""
                      className="h-11 w-full rounded-sm border border-line-strong bg-paper px-3 text-sm outline-none focus:border-accent"
                      suppressHydrationWarning
                    >
                      <option value="" disabled>
                        Select type
                      </option>
                      {PROJECT_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="block sm:col-span-2">
                    <span className="mb-1.5 block text-sm font-medium">Message</span>
                    <textarea
                      name="message"
                      required
                      rows={5}
                      className="w-full rounded-sm border border-line-strong bg-paper px-3 py-2.5 text-sm outline-none focus:border-accent"
                      placeholder="Location, size, and when you want to start"
                      suppressHydrationWarning
                    />
                  </label>
                </div>
                <button
                  type="submit"
                  className="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-sm bg-navy px-6 text-sm font-semibold text-on-navy transition-colors duration-150 hover:bg-navy-mid sm:w-auto"
                >
                  Request a quote
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      <footer className="bg-charcoal text-on-navy">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
          <div>
            <p className="font-display text-2xl font-semibold uppercase">{COMPANY.name}</p>
            <p className="mt-2 max-w-xs text-sm text-on-navy-muted">{COMPANY.tagline}</p>
          </div>
          <div className="text-sm">
            <p className="font-semibold">Visit</p>
            <p className="mt-2 text-on-navy-muted">{COMPANY.address}</p>
            <a href={`tel:${COMPANY.phoneTel}`} className="mt-3 block text-on-navy">
              {COMPANY.phoneDisplay}
            </a>
          </div>
          <nav className="flex flex-col gap-2 text-sm text-on-navy-muted" aria-label="Footer">
            {["#about", "#services", "#projects", "#contact"].map((href) => (
              <a key={href} href={href} className="hover:text-on-navy">
                {href.slice(1)}
              </a>
            ))}
          </nav>
        </div>
        <div className="border-t border-white/10 px-4 py-5 text-center text-xs text-on-navy-muted sm:px-6">
          © {new Date().getFullYear()} {COMPANY.legal}. All rights reserved.
        </div>
      </footer>

      <a
        href={COMPANY.whatsapp}
        className="fixed right-4 bottom-4 z-40 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-4 text-sm font-semibold text-accent-fg shadow-soft sm:right-6 sm:bottom-6"
        aria-label="Chat on WhatsApp"
      >
        WhatsApp
      </a>
      <a
        href={`tel:${COMPANY.phoneTel}`}
        className="fixed bottom-4 left-4 z-40 inline-flex size-12 items-center justify-center rounded-full bg-navy text-on-navy shadow-soft sm:hidden"
        aria-label="Call Collinscrown"
      >
        <Phone className="size-5" />
      </a>

      {lightbox !== null ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/90 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Project photograph"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            className="absolute top-4 right-4 inline-flex size-11 items-center justify-center rounded-sm text-on-navy"
            aria-label="Close"
            onClick={() => setLightbox(null)}
          >
            <X className="size-6" />
          </button>
          <img
            src={IMAGES[lightbox].src}
            alt={IMAGES[lightbox].alt}
            className="max-h-[86vh] max-w-full object-contain"
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      ) : null}
    </>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  autoComplete,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  autoComplete?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        autoComplete={autoComplete}
        className="h-11 w-full rounded-sm border border-line-strong bg-paper px-3 text-sm outline-none focus:border-accent"
        suppressHydrationWarning
      />
    </label>
  );
}
